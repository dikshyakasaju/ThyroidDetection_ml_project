from setuptools import setup, find_packages

setup(
    name="Thyroid_Detection_2022",
    version="0.0.1",
    description="ML project",
    author="Dikshya Pradhan",
    packages=find_packages(),
    license="MIT"
)