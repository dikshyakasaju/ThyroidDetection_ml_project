from setuptools import find_packages, setup

setup(
    name="thyroid-detection",
    version="0.0.1",
    description="Thyroid Detection ML project",
    author="Dikshya Pradhan",
    packages=find_packages(),
    license="MIT"
)
